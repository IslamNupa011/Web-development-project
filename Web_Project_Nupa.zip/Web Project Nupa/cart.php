<!DOCTYPE html>
<?php
    session_start();
     if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
   else{
?>
<html>
    <head>
        <title>Event_management</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <style>
            body{
                width:100%;
                 overflow: auto;
                
                  
            }
            ul{
                list-style-type: none;
                margin: 0px;
                padding:0px;
                background-color: #BE0101;
                overflow:hidden;
                height:100px;
                width: 100%;
                
                
            }
            li{
                float:left;
            }
            li a{
                display:block;
                text-decoration: none;
                color:white;
                text-align: center;
                padding:30px 18px;
                
            }
            li a:hover{
                color:goldenrod;
            }
            #h{
                
                position:sticky;
                top:0px;
            }
            #footer{
                height:180px;
            }
            #srvc_dropdown{
                
            }
            #middle_birthday{
                background-image: url("middle_wed3.jpg");
                background-repeat: no-repeat;
               background-size: 4000px 4000px;
            }
            div span{
                width:4000px;
                height:1500px;
                padding-left: 500px;
                padding-top: 70px;
                font-size: 35px;
            }  
            div span img{
                height:400px;
                width: 600px;
                 padding-left: 350px;
            }
            table,th,td{
                border:1px solid black;
                border-collapse: collapse;
                width: 700px;
                height: 30px;
            }
            table {
                border-spacing: 15px;
             }
        </style>
    </head>
    <body>
        <!--header-->
        <div>
        <ul id="h">
            <li style="padding: 20px;"><img style="padding: 1px;" src="picture\eventive_logo.png" alt="not found" height="49" width="73"></li>
            
            <li><a href="index.php"><b style="font-size:20px;">Home</b></a></li>
			<li><a href="wedding.php"><b style="font-size:20px;">Wedding</b></a></li>
			<li><a href="birthday.php"><b style="font-size:20px;">Birthday</b></a></li>
			<li><a href="equipment.php"><b style="font-size:20px;">Equipment</b></a></li>
			
            <li style="float:right"><a href="cart.php"><b style="font-size:20px;">User Account:<?php echo $_SESSION['email']?></b></a></li>
            <li style="float:right"><a href="logout.php"><b style="font-size:20px;">Log Out</b></a></li>
            <li style="float:top;padding-top: 27px;"><b style="font-size:20px;color:white;">Search:</b><input type="search" name="search" id="search" style="width: 200px;height:30px" onkeyup="callAjax();"></li>
           
         </ul>
            </div>
        
        <!--middle-->
        <div id="middle_birthday">
            <img src="picture\cart_pic.png" alt="weed_err" style="width:100%; height:700px" >
            
             <div style="background-color: #FB6161;display:inline-block;width:100%;height:50%;">
            <h1 style="text-align: center;color:white;">Cart</h1>
              </div>
            
            <!--choose option-->
            
          <div style="height:680px;padding-left: 270px;padding-top: 50px;">
		  
		  <!-- from datrabase-->
              
				
				<?php
				
				 try{
	                   $conn = new PDO("mysql:host=localhost;dbname=eventive", "root", "");
                       $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
					   $in=$_SESSION['id'];
	                   $a=implode($in);
		                
		                 
						 $stmt="select *from user_signup where user_id='$a'; ";
						 
						 
			            $pdostmt= $conn->query($stmt);
						 $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
						 foreach($table as $row){
							 echo"<b>User Name:</b> ".$row[1]."<br/><br/>";
							  echo"<b>User Password:</b> ".$row[2]."<h4>Change Password</h4>"."<form method='post' action='changepass.php'>"."<input type=text id=newp name=newp placeholder=Enter_new_password><br/><br/>";
							   echo"<b>User phone:</b> ".$row[3]."<br/><br/> ";
							    echo"<b>User Email:</b> ".$row[4]."<br/><br/> ";
								 echo"";
						 }
						 
		               if($pdostmt->rowCount()==0){
                        echo "<tr><td colspan='5' style='text-align:center'>No Data Exists</td></tr>";
                
                    }
                    }
                 catch (PDOException $ex) {
                    echo "<tr><td colspan='5' style='text-align:center'>No Data Exists</td></tr>";
                }
							
							
							?>
				
	<li style="float:middle;padding-top: 28px;list-style-type:none;">
	
			<table style="width:89%">
            <thead>
                <tr>
				    
                    <th>Cart_Id</th>
                    <th>User_Id</th>
                    
                    <th>Payment</th>
					<th>Service_details</th>
					<th>Booking_Id</th>
					
					<th>Service_id</th>
                    
                </tr>
            </thead>
            <tbody id="tbody">
                <tr>
                    <?php
                    try {
                        $con=new PDO("mysql:host=localhost;dbname=eventive","root","");
                        $stmt="select *from cart where user_id='$a'";
                        $pdostmt=$con->query($stmt);
                        $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
                        
                        foreach($table as $row){
                         echo "<tr>
						        <td>$row[0]</td>
								<td>$row[1]</td>
								<td>$row[2]</td>
								<td>$row[3]</td>
								<td>$row[4]</td>
								<td>$row[5]</td>
								</tr>";
				           
						   
                      
						   
                        }
                        
                    } catch (Exception $ex) {
                        echo "<tr><td colspan='6' style='text-align:center'>No data exists</td></tr>";
                    }
                    ?>
                </tr>

            </tbody>

        </table> 
		  <?php
		        try {
                        $con=new PDO("mysql:host=localhost;dbname=eventive","root","");
						$in=$_SESSION['id'];
	                    $a=implode($in);
                        $stmt="SELECT SUM(total_payment) FROM cart where user_id='$a';";
                        $pdostmt=$con->query($stmt);   
		                $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
						
						
						foreach($table as $row){
							echo"<br/><br/><b>Total Payment:</b> ".$row[0]."<br/><br/>";
						}
	 
				}
				catch (Exception $ex) {
                        echo "<tr><td colspan='5' style='text-align:center'>No data exists</td></tr>";
                    }
			   
		  ?>
		
		<a href="payment.php"><input type="button" value="Click to pay" style="width:250px;"></a>
              
            </div>
        
        
       
        
        <!--footer-->
        <div>
            <ul >
                <li style="padding-left:100px;"><a href=""><b style="font-size:20px;">About Us</b></a></li>
              
                <li style="padding-left:260px;" ><a href=""><b style="font-size:20px;">Contact Us</b></a></li>
                
                 <li style="padding-left:200px;" ><a href=""><b style="font-size:20px;">Social Links</b></a></li>
                
                <li style="float:right;padding-right:100px;"><a href=""><b style="font-size:20px;">Message</b></a></li>
                
                <li><a href=""></a></li>
               
            </ul>
            
        </div>
        
        <div>
            <ul id="footer">
                <li style="padding-left:80px;font-size:17px;">Eventive is an event management<br>web platform to support multiple events.</li>
                <li style="padding-left:125px;font-size:17px;">Address:Dhanmondi<br>Phone:0181-xxxxxxx<br>Email:abc@gmail.com</li>
                <li style="color:white;padding-left:150px;"><a href="#" class="fa fa-facebook"></a></li>
                 <li style="color:white;padding-left:0px;"><a href="#" class="fa fa-twitter"></a></li>
                  <li style="color:white;padding-left:0px;"><a href="#" class="fa fa-google"></a></li>
                   <li style="color:white;padding-left:0px;"><a href="#" class="fa fa-yahoo"></a></li>
                   
                 <li style="padding-right:1px;font-size:17px;">Email:<input type="email" name="email" id="email1" style="padding-right:1px;margin-left: 40px;"></li>
                 <li style="padding:30px;font-size:17px;" >Message:<textarea></textarea></li>
                  <li style="padding-left:1200px;font-size:17px;"><input type="submit" value="Submit"></li>
            </ul>
        </div>
		
		<script>
		 function callAjax() {
                var curvalue=document.getElementById('search').value;
                
                var request=new XMLHttpRequest();
                
                request.onreadystatechange= function(){
                    if(this.readyState==4 && this.status==200){
                        document.getElementById('tbody').innerHTML=request.responseText;
                    }
                }
                
                request.open("GET","internal.php?search="+curvalue, true);
                request.send();
            }
			</script>
		
		
		
        
    </body>
</html>
<?php

   }
   
   ?>