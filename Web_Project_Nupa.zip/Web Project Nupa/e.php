<?php

session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
else{
  $serveraddr = "localhost";
    $username = "root";
      $password="";                
    $dbname = "eventive";
   
   
   $user_email=$_SESSION['email'];
	
	
	
	$in=$_SESSION['id'];
	$a=implode($in);
   
    $nam=$_POST['name'];
    $quant=$_POST['num'];
   
   
 
   try{
	    $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt2="select booking_id from booking order by booking_id desc limit 1;";
			 $pdostmt=$conn->query($stmt2);
			 $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
			  $b=$table[0];
			  $n=implode($b);
			  
			  
			   $stmt4="select service_id from services order by service_id desc limit 1;";
			 $pdostmt=$conn->query($stmt4);
			 $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
			  $c=$table[0];
			  $d=implode($c);
			
			  
			$stmt="insert into equipment values('','$nam','$quant','500','$user_email','aa@gmail.com','$a');";
		    $stmt_1="insert into cart values('','$a','500','equipment','$n','$d');";
		
		
		
		$conn->exec($stmt);
		$conn->exec($stmt_1);
		
		echo "<script>window.alert('Form Submission Successful');</script>";
		echo "<script>window.alert('Insertion into equipment done');</script>";
		echo "<script>window.alert('Insertion into cart done');</script>";
		echo "<script>window.location.assign('index_1.php');</script>";
   }
   catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }
   
}
?>