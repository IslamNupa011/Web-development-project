
<?php

 session_start();
     if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
   else{

	$serveraddr = "localhost";
    $username = "root";
	$password="";
                      
    $dbname = "eventive";
	
	
	$amount=$_POST['amount'];
	$id=$_SESSION['id'];
	$i=implode($id);
	$pin=$_POST['pin'];
             
	
    


try {
             $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			 
			       $stmt2="SELECT cart_id FROM cart ORDER BY cart_id DESC LIMIT 1;"; 
                        $pdostmt=$conn->query($stmt2); 
                        $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
						$v=$table[0];
						$vb=implode($v);
						
						$stmt_2 = "insert into payment values('','$vb','Bkash','$amount','$i','$pin');"; 
			  
                        $conn->exec($stmt_2);

			 
			  
				       
			  
			  
			  echo "<script>window.alert('Payment Done!!!');</script>";
			  echo "<script>window.location.assign('payment.php');</script>";

			   
			   
			 } catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }
   }


?>

