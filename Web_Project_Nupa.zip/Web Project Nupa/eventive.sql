-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2019 at 04:27 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eventive`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_user`
--

CREATE TABLE `admin_user` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(30) DEFAULT NULL,
  `admin_email` varchar(30) DEFAULT NULL,
  `admin_password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_user`
--

INSERT INTO `admin_user` (`admin_id`, `admin_name`, `admin_email`, `admin_password`) VALUES
(1, 'Aa', 'aa@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_id` int(11) NOT NULL,
  `booking_service_name` varchar(20) DEFAULT NULL,
  `confirm` varchar(4) DEFAULT NULL,
  `e_time` varchar(10) DEFAULT NULL,
  `e_date` varchar(10) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `e_address` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_id`, `booking_service_name`, `confirm`, `e_time`, `e_date`, `service_id`, `user_id`, `admin_id`, `e_address`) VALUES
(9, 'wedding', 'Yes', '10:00am', '2019-01-05', 45, 2, 1, 'Galimpur'),
(10, 'birthday', 'Yes', '4:20pm', '2019-01-04', 36, 1, 1, 'joypara'),
(11, 'birthday', 'Yes', '3:00pm', '2019-01-02', 42, 1, 1, 'badda'),
(12, 'birthday', 'Yes', '1:00pm', '2018-12-10', 43, 1, 1, 'barha'),
(13, 'wedding', 'Yes', '10:00pm', '2019-01-02', 46, 2, 1, 'satarkul'),
(24, 'wedding', 'Yes', '1:00pm', '2019-01-04', 47, 1, 1, 'gulshan'),
(25, 'wedding', 'Yes', '4:20pm', '2018-12-28', 35, 1, 1, 'nawabgonj'),
(31, 'wedding', 'Yes', '10:00am', '2019-01-05', 45, 2, 1, 'Galimpur'),
(34, 'wedding', 'Yes', '4:20pm', '2018-12-12', 38, 1, 1, 'dhaka'),
(35, 'wedding', 'Yes', '4:20pm', '2018-12-28', 35, 1, 1, 'nawabgonj'),
(36, 'wedding', 'Yes', '1:00pm', '2018-11-30', 48, 2, 1, 'dhaka'),
(39, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(40, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(42, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(44, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(46, 'wedding', 'Yes', '3:00am', '2019-03-16', 53, 4, 1, 'sridhorpur'),
(48, 'wedding', 'Yes', '3:00am', '2019-03-16', 53, 4, 1, 'sridhorpur'),
(49, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(51, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(52, 'wedding', 'Yes', '3:00am', '2019-03-16', 53, 4, 1, 'sridhorpur'),
(53, 'wedding', 'Yes', '2:00pm', '2019-02-13', 52, 3, 1, 'sholla'),
(54, 'wedding', 'Yes', '12:00pm', '2019-02-16', 51, 3, 1, 'singjur'),
(55, 'wedding', 'Yes', '11:05am', '2019-01-13', 50, 2, 1, 'gobindopur'),
(56, 'wedding', 'Yes', '11:00am', '2019-01-16', 49, 2, 1, 'anta'),
(57, 'wedding', 'Yes', '3:02am', '2019-03-13', 54, 4, 1, 'tikorpur'),
(58, 'wedding', 'Yes', '3:00am', '2019-03-16', 53, 4, 1, 'sridhorpur'),
(59, 'wedding', 'Yes', '2:00pm', '2019-02-13', 52, 3, 1, 'sholla'),
(60, 'wedding', 'Yes', '12:00pm', '2019-02-16', 51, 3, 1, 'singjur'),
(61, 'wedding', 'Yes', '5:05pm', '2018-09-13', 59, 2, 1, 'rayerbazar'),
(62, 'wedding', 'Yes', '5:05pm', '2018-09-13', 59, 2, 1, 'rayerbazar'),
(63, 'wedding', 'Yes', '4:20pm', '2018-12-28', 35, 1, 1, 'nawabgonj'),
(64, 'wedding', 'Yes', '4:20pm', '2018-12-28', 35, 1, 1, 'nawabgonj'),
(66, 'wedding', 'Yes', '4:20pm', '2018-12-28', 35, 1, 1, 'nawabgonj'),
(67, 'wedding', 'Yes', '4:20pm', '2018-12-12', 38, 1, 1, 'dhaka'),
(68, 'wedding', 'Yes', '10:00am', '2019-01-05', 45, 2, 1, 'Galimpur'),
(69, 'birthday', 'Yes', '3:00pm', '2019-07-16', 65, 4, 1, 'tajnagar'),
(70, 'birthday', 'Yes', '5:00pm', '2019-06-19', 64, 4, 1, 'mazpara'),
(71, 'birthday', 'Yes', '4:20pm', '2019-02-03', 63, 3, 1, 'postoffice'),
(72, 'birthday', 'Yes', '3:00pm', '2019-02-05', 62, 3, 1, 'durgapur'),
(73, 'birthday', 'Yes', '5:00pm', '2018-12-11', 61, 1, 1, 'modhubazar'),
(74, 'birthday', 'Yes', '2:20pm', '2018-07-25', 60, 1, 1, 'bottola'),
(75, 'wedding', 'Yes', '12:30pm', '2019-06-08', 66, 3, 1, 'noakhali'),
(76, 'wedding', 'Yes', '2:00pm', '2019-02-13', 52, 3, 1, 'sholla'),
(77, 'birthday', 'Yes', '5:00pm', '2018-12-11', 61, 1, 1, 'modhubazar'),
(78, 'birthday', 'Yes', '3:01am', '2019-01-02', 67, 2, 1, 'barikhali'),
(79, 'birthday', 'Yes', '6:00pm', '2019-01-06', 71, 4, 1, 'komorgonj'),
(80, 'birthday', 'Yes', '2:01am', '2019-01-05', 70, 4, 1, 'rampura'),
(81, 'birthday', 'Yes', '3:01am', '2019-01-02', 67, 2, 1, 'barikhali');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `total_payment` varchar(6) DEFAULT NULL,
  `service_details` varchar(20) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `user_id`, `total_payment`, `service_details`, `booking_id`, `service_id`) VALUES
(23, 4, '4000', 'wedding', 57, 54),
(24, 4, '4000', 'wedding', 58, 53),
(25, 3, '4000', 'wedding', 59, 52),
(26, 3, '4000', 'wedding', 60, 51),
(28, 2, '4000', 'wedding', 62, 59),
(29, 1, '4000', 'wedding', 66, 35),
(30, 1, '4000', 'wedding', 67, 38),
(31, 2, '4000', 'wedding', 68, 45),
(32, 4, '4000', 'birthday', 69, 65),
(33, 4, '4000', 'birthday', 70, 64),
(34, 3, '4000', 'birthday', 71, 63),
(35, 3, '4000', 'birthday', 72, 62),
(36, 1, '4000', 'birthday', 73, 61),
(37, 1, '4000', 'birthday', 74, 60),
(38, 3, '4000', 'wedding', 75, 66),
(40, 0, '500', 'equipment', 75, 66),
(44, 3, '4000', 'wedding', 76, 52),
(45, 1, '4000', 'birthday', 77, 61),
(47, 2, '500', 'equipment', 77, 66),
(48, 1, '500', 'equipment', 77, 66),
(49, 3, '500', 'equipment', 77, 66),
(50, 2, '4000', 'birthday', 78, 67),
(51, 4, '4000', 'birthday', 79, 71),
(52, 4, '4000', 'birthday', 80, 70),
(53, 2, '4000', 'birthday', 81, 67);

-- --------------------------------------------------------

--
-- Table structure for table `equipment`
--

CREATE TABLE `equipment` (
  `e_id` int(11) NOT NULL,
  `e_name` varchar(50) DEFAULT NULL,
  `e_quantity` int(11) DEFAULT NULL,
  `e_price` varchar(40) DEFAULT NULL,
  `user_email` varchar(20) DEFAULT NULL,
  `admin_email` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipment`
--

INSERT INTO `equipment` (`e_id`, `e_name`, `e_quantity`, `e_price`, `user_email`, `admin_email`, `user_id`) VALUES
(2, 'ballon', 12, '500', 'a@gmail.com', 'aa@gmail.com', 1),
(3, 'cake', 1, '500', 'a@gmail.com', 'aa@gmail.com', 1),
(4, 'candle', 10, '500', 'a@gmail.com', 'aa@gmail.com', 1),
(5, 'cake', 1, '500', 'b@gmail.com', 'aa@gmail.com', 2),
(6, 'candle', 4, '500', 'b@gmail.com', 'aa@gmail.com', 2),
(7, 'cake', 1, '500', 'c@gmail.com', 'aa@gmail.com', 3),
(8, 'ballon', 5, '500', 'c@gmail.com', 'aa@gmail.com', 3),
(9, 'cake', 2, '500', 'd@gmail.com', 'aa@gmail.com', 4),
(10, 'ballon', 6, '500', 'd@gmail.com', 'aa@gmail.com', 4),
(11, 'cake', 2, '500', 'b@gmail.com', 'aa@gmail.com', 2),
(12, 'ballon', 7, '500', 'b@gmail.com', 'aa@gmail.com', 2),
(13, 'ballon', 10, '500', 'a@gmail.com', 'aa@gmail.com', 1),
(14, 'cake', 3, '500', 'c@gmail.com', 'aa@gmail.com', 3);

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `msg_id` int(11) NOT NULL,
  `user_email` varchar(20) DEFAULT NULL,
  `message` varchar(100) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`msg_id`, `user_email`, `message`, `user_id`) VALUES
(1, 'b@gmail.com', 'hi', 2),
(2, 'b@gmail.com', 'hlw i m ', 2),
(5, 'a@gmail.com', 'can u help me?', 1),
(6, 'a@gmail.com', 'r u available?', 1),
(7, 'a@gmail.com', 'r', 1),
(8, 'd@gmail.com', 'r u there?', 4);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL,
  `cart_id` int(11) DEFAULT NULL,
  `payment_method` varchar(10) DEFAULT NULL,
  `payment_amount` varchar(6) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `Trx_id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_id`, `cart_id`, `payment_method`, `payment_amount`, `user_id`, `Trx_id`) VALUES
(57, 38, 'Bkash', ' 16000', 1, 'bjkfse'),
(58, 38, 'Bkash', '16000', 1, 'abcd'),
(59, 38, 'Bkash', ' 8000', 2, 'ryrgv'),
(60, 38, 'Bkash', ' 8000', 2, 'hgfsdjgh'),
(61, 38, 'Bkash', '20000', 3, 'sdrrtd'),
(62, 38, 'Bkash', '20000', 3, 'bhyyhg'),
(63, 38, 'Bkash', ' 16000', 4, 'liuvfs'),
(64, 40, 'Bkash', ' 8000', 2, 'gfhfsdrerutr'),
(65, 47, 'Bkash', '9000', 2, 'njuihg'),
(66, 53, 'Bkash', '24500', 3, 'fdggg');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_admin_email` varchar(30) DEFAULT NULL,
  `service_name` varchar(30) DEFAULT NULL,
  `service_available` varchar(4) DEFAULT NULL,
  `service_time` varchar(11) DEFAULT NULL,
  `service_date` varchar(11) DEFAULT NULL,
  `service_price` varchar(6) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_admin_email`, `service_name`, `service_available`, `service_time`, `service_date`, `service_price`, `admin_id`, `user_id`, `address`) VALUES
(35, 'NULL', 'wedding', 'Yes', '4:20pm', '2018-12-28', 'NULL', 1, 1, 'nawabgonj'),
(36, 'NULL', 'birthday', 'No', '4:20pm', '2019-01-04', 'NULL', 1, 1, 'joypara'),
(38, 'NULL', 'wedding', 'Yes', '4:20pm', '2018-12-12', 'NULL', 1, 1, 'dhaka'),
(39, 'NULL', 'wedding', 'Yes', '4:20pm', '2019-01-05', 'NULL', 1, 1, 'n'),
(41, 'NULL', 'wedding', 'Yes', '4:20pm', '2018-11-27', 'NULL', 1, 1, 'azimpur'),
(42, 'NULL', 'birthday', 'Yes', '3:00pm', '2019-01-02', 'NULL', 1, 1, 'badda'),
(43, 'NULL', 'birthday', 'Yes', '1:00pm', '2018-12-10', 'NULL', 1, 1, 'barha'),
(44, 'NULL', 'birthday', 'No', '4:00pm', '2018-12-16', 'NULL', 1, 1, 'gulisthan'),
(45, 'NULL', 'wedding', 'Yes', '10:00am', '2019-01-05', 'NULL', 1, 2, 'Galimpur'),
(46, 'NULL', 'wedding', 'Yes', '10:00pm', '2019-01-02', 'NULL', 1, 2, 'satarkul'),
(47, 'NULL', 'wedding', 'Yes', '1:00pm', '2019-01-04', 'NULL', 1, 1, 'gulshan'),
(48, 'NULL', 'wedding', 'Yes', '1:00pm', '2018-11-30', 'NULL', 1, 2, 'dhaka'),
(49, 'NULL', 'wedding', 'Yes', '11:00am', '2019-01-16', 'NULL', 1, 2, 'anta'),
(50, 'NULL', 'wedding', 'Yes', '11:05am', '2019-01-13', 'NULL', 1, 2, 'gobindopur'),
(51, 'NULL', 'wedding', 'Yes', '12:00pm', '2019-02-16', 'NULL', 1, 3, 'singjur'),
(52, 'NULL', 'wedding', 'Yes', '2:00pm', '2019-02-13', 'NULL', 1, 3, 'sholla'),
(53, 'NULL', 'wedding', 'Yes', '3:00am', '2019-03-16', 'NULL', 1, 4, 'sridhorpur'),
(54, 'NULL', 'wedding', 'Yes', '3:02am', '2019-03-13', 'NULL', 1, 4, 'tikorpur'),
(59, 'NULL', 'wedding', 'Yes', '5:05pm', '2018-09-13', 'NULL', 1, 2, 'rayerbazar'),
(60, 'NULL', 'birthday', 'Yes', '2:20pm', '2018-07-25', 'NULL', 1, 1, 'bottola'),
(61, 'NULL', 'birthday', 'Yes', '5:00pm', '2018-12-11', 'NULL', 1, 1, 'modhubazar'),
(62, 'NULL', 'birthday', 'Yes', '3:00pm', '2019-02-05', 'NULL', 1, 3, 'durgapur'),
(63, 'NULL', 'birthday', 'Yes', '4:20pm', '2019-02-03', 'NULL', 1, 3, 'postoffice'),
(64, 'NULL', 'birthday', 'Yes', '5:00pm', '2019-06-19', 'NULL', 1, 4, 'mazpara'),
(65, 'NULL', 'birthday', 'Yes', '3:00pm', '2019-07-16', 'NULL', 1, 4, 'tajnagar'),
(66, 'NULL', 'wedding', 'Yes', '12:30pm', '2019-06-08', 'NULL', 1, 3, 'noakhali'),
(67, 'NULL', 'birthday', 'Yes', '3:01am', '2019-01-02', 'NULL', 1, 2, 'barikhali'),
(68, 'NULL', 'birthday', 'NULL', '1:01am', '2019-01-03', 'NULL', 1, 4, 'sayednagar'),
(70, 'NULL', 'birthday', 'Yes', '2:01am', '2019-01-05', 'NULL', 1, 4, 'rampura'),
(71, 'NULL', 'birthday', 'Yes', '6:00pm', '2019-01-06', 'NULL', 1, 4, 'komorgonj');

-- --------------------------------------------------------

--
-- Table structure for table `user_signup`
--

CREATE TABLE `user_signup` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(30) DEFAULT NULL,
  `user_password` varchar(30) DEFAULT NULL,
  `user_phone` varchar(11) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_address` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_signup`
--

INSERT INTO `user_signup` (`user_id`, `user_name`, `user_password`, `user_phone`, `user_email`, `user_address`) VALUES
(1, 'A', '1234', '01818009809', 'a@gmail.com', 'Dhaka'),
(2, 'B', '1234', '01818009809', 'b@gmail.com', 'Chittagong'),
(3, 'C', '1234', '01818009809', 'c@gmail.com', 'Rangpur'),
(4, 'D', '1234', '01818009809', 'd@gmail.com', 'Rajshahi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_user`
--
ALTER TABLE `admin_user`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `service_id` (`service_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `booking_id` (`booking_id`),
  ADD KEY `service_id` (`service_id`);

--
-- Indexes for table `equipment`
--
ALTER TABLE `equipment`
  ADD PRIMARY KEY (`e_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`msg_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `cart_id` (`cart_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_signup`
--
ALTER TABLE `user_signup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_user`
--
ALTER TABLE `admin_user`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `equipment`
--
ALTER TABLE `equipment`
  MODIFY `e_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `msg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT for table `user_signup`
--
ALTER TABLE `user_signup`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `booking_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`),
  ADD CONSTRAINT `booking_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_signup` (`user_id`),
  ADD CONSTRAINT `booking_ibfk_3` FOREIGN KEY (`admin_id`) REFERENCES `admin_user` (`admin_id`);

--
-- Constraints for table `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`booking_id`),
  ADD CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`service_id`) REFERENCES `services` (`service_id`);

--
-- Constraints for table `equipment`
--
ALTER TABLE `equipment`
  ADD CONSTRAINT `equipment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_signup` (`user_id`);

--
-- Constraints for table `msg`
--
ALTER TABLE `msg`
  ADD CONSTRAINT `msg_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_signup` (`user_id`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`cart_id`) REFERENCES `cart` (`cart_id`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_signup` (`user_id`);

--
-- Constraints for table `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `services_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin_user` (`admin_id`),
  ADD CONSTRAINT `services_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user_signup` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
