<?php

    session_start();
     if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
 else{
	 
$searchval = "";
if (isset($_GET['search']))
    $searchval = $_GET['search'];

try {
    $con = new PDO("mysql:host=localhost;dbname=eventive", "root", "");
	
	 $in=$_SESSION['id'];
	 $a=implode($in);

    $stmt = "select *from cart where service_details like '%$searchval%' and user_id='$a';";
    $pdostmt = $con->query($stmt);
    $table = $pdostmt->fetchAll(PDO::FETCH_NUM);

    $htmlcode="";
    foreach ($table as $row) {
        $htmlcode.="<tr>
		              <td>$row[0]</td>
					  <td>$row[1]</td>
					  <td>$row[2]</td>
					  <td>$row[3]</td>
					  <td>$row[4]</td>
					  <td>$row[5]</td>
       </tr>";
    }
    echo $htmlcode;
} catch (PDOException $ex) {
    echo "<tr><td colspan='6' style='text-align:center'>No Data Exists</td></tr>";
}

 }
?>
