
<?php


	$serveraddr = "localhost";
    $username = "root";
	$password="";
                      
    $dbname = "eventive";
	
	
	$service=$_POST['id'];//service  id
	$t=$_POST['time'];
	$d=$_POST['date'];
	$u_i=$_POST['ui'];
	$add=$_POST['address'];
	$avail="Yes";
	                
	
    


try {
             $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			 
			  $stmt = "UPDATE services SET service_available='$avail' WHERE service_id='$service'";
			   $stmt1="insert into booking values('','birthday','$avail','$t','$d','$service','$u_i','1','$add');";
              $conn->exec($stmt);
			  $conn->exec($stmt1);
			  
			  echo "<script>window.alert('Service Allocated Successfully');</script>";
			 echo "<script>window.alert('Booking Allocated Successfully');</script>";
			 
			 
			 $stmt2="select *from booking order by booking_id desc limit 1;";
			 $pdostmt=$conn->query($stmt2);
			 $table=$pdostmt->fetchAll(PDO::FETCH_NUM);
			  $a=$table[0];
			  $n=implode($a);
			  
			  $stmt3="insert into cart values('','$u_i','4000','birthday','$n','$service');";
			  $conn->exec($stmt3);
			  
			  
				       
			  
			  
			  echo "<script>window.alert('Cart updated Successfully');</script>";
			  
			   echo "<script>window.location.assign('bsr.php');</script>";
			   
			 } catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }



?>

