<?php

session_start();
if (!isset($_SESSION['email'])) {
    echo "<script>window.location.assign('index.php')</script>";
	
}
else{
  $serveraddr = "localhost";
    $username = "root";
      $password="";                
    $dbname = "eventive";
   
   
   $user_email=$_SESSION['email'];
	
	
	
	$in=$_SESSION['id'];
	$a=implode($in);
   
   $date=$_POST['date'];
   $time=$_POST['time'];
  
   $address=$_POST['address'];
   
   

   try{
	    $conn = new PDO("mysql:host=$serveraddr;dbname=$dbname", $username, $password);
             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		$stmt="insert into services values('','NULL','wedding','NULL','$time','$date','NULL','1','$a','$address');";
		
		 //$stmt = "insert into services values(' ','NULL','Weeding','NULL','$time','$date','NULL','1','$a','$address');";
		
		$conn->exec($stmt);
		echo "<script>window.alert('Form Submission Successful,Wait For Admin Response');</script>";
		echo "<script>window.location.assign('index_1.php');</script>";
   }
   catch (PDOException $ex) {
                                echo "<script>showalert('Sign Up Error');</script>";
                            }
   
}
?>